#!/bin/sh
DIR="/tmp/settings"
DOWNLOAD1="http://files.dnsfor.me/lista/settings.tar.gz"
STATUS=0

echo "     **Ažuriranje liste kanala**  "
/bin/echo " "
/bin/echo "     U procesu preuzimanja pričekajte..."
rm /tmp/settings.tar.gz > /dev/null 2>&1; 
rm -rf /tmp/settings> /dev/null 2>&1; 
if wget $DOWNLOAD1 -O /tmp/settings.tar.gz > /dev/null 2>&1; then
mkdir /tmp/settings
tar -xzf /tmp/settings.tar.gz -C /tmp/settings/
rm -rf /tmp/settings.tar.gz
if [ "$(ls -A $DIR)" ]; then
/bin/echo "      ... preuzimanje je uspešno, ažuriram listu."
/bin/echo " "
chmod +x /usr/script/*.sh
STATUS=1
else
rm -rf /tmp/settings
STATUS=0
fi
fi

if [ $STATUS -eq 0 ]; then
if wget $DOWNLOAD2 -O /tmp/settings.tar.gz > /dev/null 2>&1; then
mkdir /tmp/settings
tar -xzf /tmp/settings.tar.gz -C /tmp/settings/
rm -rf /tmp/settings.tar.gz
if [ "$(ls -A $DIR)" ]; then
/bin/echo "      ... preuzimanje je uspešno, ažuriram listu."
/bin/echo " "
STATUS=1
else
/bin/echo " "
/bin/echo "    ... ažuriranje nije uspelo ili nema internet veze!"
/bin/echo "                   Probajte kasnije!              "
/bin/echo " "
rm -rf /tmp/settings
exit 0
fi
fi
fi

if [ $STATUS -eq 1 ]; then
cat /tmp/settings/news.txt
cd /etc/enigma2
mv -f userbouquet.favourites.tv /tmp/settings/
mv -f userbouquet.favourites.radio /tmp/settings/
rm -rf *.tv *.radio satellites.xml
cd /tmp/settings/etc/enigma2
mv -f * /etc/enigma2/
cd /tmp/settings/etc/tuxbox
mv -f satellites.xml /etc/tuxbox/
cd /tmp/settings
mv -f userbouquet.favourites.tv /etc/enigma2/
mv -f userbouquet.favourites.radio /etc/enigma2/
cd /tmp/settings/usr/script
mv -f * /usr/script/
cd /tmp/settings/usr/share/enigma2
mv -f encoding.conf /usr/share/enigma2
rm -rf /tmp/settings
cd /usr/script
rm -rf NEW_CHANGES_info_userscript.sh 
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0  > /dev/null 2>&1
/bin/echo " "
/bin/echo " Uspešno ažuriranje! Izađite iz aplikacije!  "
/bin/echo " "
chmod +x /usr/script/*.sh

	else

/bin/echo " "
/bin/echo "    ... ažuriranje nije uspelo ili nema internet veze!"
/bin/echo "                   Probajte kasnije!              "
/bin/echo " "
rm -rf /tmp/settings	 
chmod +x /usr/script/*.sh
fi

exit 1